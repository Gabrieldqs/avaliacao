<!DOCTYPE html>
<html>
    <head>
        
        <?php $__env->startSection('title', 'Busca de Aluno'); ?>
    </head>

    <style>
    .campo{
        width: 100px;
    }
    #campo1{
        width: 100px;
    }
    </style>

<body>
    <div class="botoes">
        <a href="/cadastrar" class="botao"> Cadastrar </a> <a href="/buscaDeAluno" class="botao"> Busca de Aluno</a> <a href="/notas" class="botao"> Notas</a>
    </div>

    <div class="corpo">
        <form action="buscar" method="post">
            <table>
                <tr>
                    <?php echo e(csrf_field()); ?>

                    <td id="campo1">Nome </td>
                    <td><input type="text" name="nome"> </td>
                    <td><input type="submit" name="submit" value="buscar" id="submit"></td>
                </tr>

                <?php if(!empty($aluno)): ?>
                <tr>
                    <td class="campo">Nome</td>
                    <td><?php echo e(isset($aluno->nome) ? $aluno->nome : ''); ?></td>
                </tr>
                <tr>
                    <td class="campo">Matricula</td>
                    <td><?php echo e(isset($aluno->matricula) ? $aluno->matricula : ''); ?></td>
                </tr>
                <tr>
                    <td class="campo">Nota </td>
                    <td><?php echo e(isset($aluno->nota) ? $aluno->nota : ''); ?></td>
                </tr>
                <tr>
                    <td class="campo">Rua</td>
                    <td><?php echo e(isset($endereco->rua) ? $endereco->rua : ''); ?></td>
                </tr>
                <tr>
                    <td class="campo">Número </td>
                    <td><?php echo e(isset($endereco->numero) ? $endereco->numero : ''); ?></td>
                </tr>
                <tr>
                    <td class="campo">Bairro </td>
                    <td><?php echo e(isset($endereco->bairro) ? $endereco->bairro : ''); ?></td>
                </tr>
                <?php endif; ?>

            </table>    
        </form>
    </div>

</body>
</html>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>