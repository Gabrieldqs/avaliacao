<!DOCTYPE html>
<html>
	<head>
		
		<?php $__env->startSection('title', 'Notas'); ?>
	</head>

	<style>
    .nomes{
    	width: 200px;
    }
    </style>
    
<body>
	<div class="botoes">
        <a href="/cadastrar" class="botao"> Cadastrar </a> <a href="/buscaDeAluno" class="botao"> Busca de Aluno</a> <a href="/notas" class="botao"> Notas</a>
    </div>

		<div class="corpo">
			<table>
				<?php foreach($data as $aluno): ?>
				<tr> 
					<td class="nomes"><?php echo e($aluno->nome); ?></td>
					<td><?php echo e($aluno->nota); ?></td>
				</tr>
				<?php endforeach; ?>
			</table>	
		</div>
</body>
</html>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>