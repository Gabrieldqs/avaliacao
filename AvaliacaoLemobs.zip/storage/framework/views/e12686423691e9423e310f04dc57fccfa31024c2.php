<!DOCTYPE html>
<html>
<body>

<a href="/cadastrar"> Teste</a>

</body>
</html>
